package com.example.scanlife;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.Window;
import android.view.WindowManager;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;
import android.widget.TextView;

public class opening extends AppCompatActivity {

    ImageView img;
    TextView tv;
    Animation top,bottom;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        this.getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,WindowManager.LayoutParams.FLAG_FULLSCREEN);
        getSupportActionBar().hide();
        setContentView(R.layout.activity_opening);
        img = findViewById(R.id.mainlogoimg);
        tv = findViewById(R.id.sublogo);
        top = AnimationUtils.loadAnimation(getApplicationContext(),R.anim.tob);
        bottom = AnimationUtils.loadAnimation(getApplicationContext(),R.anim.bot);
        img.setAnimation(top);
        tv.setAnimation(bottom);
        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                Intent i = new Intent(opening.this,MainActivity.class);
                startActivity(i);
                finish();

            }
        },2000);
    }
}