package com.example.scanlife;

import androidx.activity.result.ActivityResultLauncher;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.journeyapps.barcodescanner.ScanContract;
import com.journeyapps.barcodescanner.ScanOptions;

public class MainActivity extends AppCompatActivity {
    Button b1,b2,b3;
    ImageButton ib;
    EditText et1,et2;
    String username,pass;
    public static final  String SHARED_PREFS = "shredprefs";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        getSupportActionBar().setTitle("Login");
        b1=findViewById(R.id.login);
        b2=findViewById(R.id.signup);

        b3=findViewById(R.id.numbers);
        et1=findViewById(R.id.name);

        et2=findViewById(R.id.password);
        ib=findViewById(R.id.scan);
        check();



        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                username = et1.getText().toString();
                pass = et2.getText().toString();
                if(username.equals("") || pass.equals("")){
                    Toast.makeText(MainActivity.this, "Please fill up all fields", Toast.LENGTH_SHORT).show();
                }


                FirebaseDatabase db = FirebaseDatabase.getInstance();
                DatabaseReference key = db.getReference(username);
                key.addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                        String value = snapshot.getValue(String.class);
                        if (value.equals(pass)) {
                            SharedPreferences sharedPreferences = getSharedPreferences(SHARED_PREFS,MODE_PRIVATE);
                            SharedPreferences.Editor editor = sharedPreferences.edit();

                            editor.putString("name","true");
                            editor.apply();


                            Toast.makeText(MainActivity.this, "login success", Toast.LENGTH_SHORT).show();
                            Intent i = new Intent(MainActivity.this, Login_Activity.class);
                            startActivity(i);

                        } else
                        {

                            Toast.makeText(MainActivity.this, "Login failed", Toast.LENGTH_LONG).show();
                        }
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {

                    }
                });

            }
        });
        b2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i1=new Intent(MainActivity.this,Signup_Activity.class);
                startActivity(i1);

            }
        });
        b3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i2=new Intent(MainActivity.this,Numbers_Activity.class);
                startActivity(i2);
            }
        });
        ib.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                scanCode();

            }

            private void scanCode() {
                ScanOptions options=new ScanOptions();
                options.setPrompt("Volume up to flash on");
                options.setBeepEnabled(true);
                options.setOrientationLocked(true);
                options.setCaptureActivity(CaptureAct.class);
                barLauncher.launch(options);


            }
            ActivityResultLauncher<ScanOptions> barLauncher=registerForActivityResult(new ScanContract(),result ->
            {
                if (result.getContents()!=null)
                {
                    AlertDialog.Builder builder=new AlertDialog.Builder(MainActivity.this);
                    builder.setTitle("Result");
                    builder.setMessage(result.getContents());
                    builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            dialog.dismiss();
                        }
                    }).show();


                }
            });
        });
    }

    private void check() {
        SharedPreferences sharedPreferences = getSharedPreferences(SHARED_PREFS,MODE_PRIVATE);
        String checking = sharedPreferences.getString("name","");
        if(checking.equals("true")){
            Intent i = new Intent(MainActivity.this, Login_Activity.class);
            startActivity(i);
            finish();
        }
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        finishAffinity();
    }
}