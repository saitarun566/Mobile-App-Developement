package com.example.scanlife;

import static com.example.scanlife.R.*;


import androidx.appcompat.app.AppCompatActivity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.drawable.BitmapDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.Toast;

import com.google.zxing.BarcodeFormat;
import com.google.zxing.MultiFormatWriter;
import com.google.zxing.WriterException;
import com.google.zxing.common.BitMatrix;
import com.journeyapps.barcodescanner.BarcodeEncoder;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

public class Login_Activity extends AppCompatActivity{
    long i = 0;
    RelativeLayout relativeLayout;
    EditText et1,et2,et3,et4;
    Button qrgen,dqr;
    ImageButton im1;
    ImageView qr1;
    Bitmap bitmap;
    BitmapDrawable bitmapd;
    public static final  String SHARED_PREFS = "shredprefs";




    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(layout.activity_login);
        getSupportActionBar().setTitle("Add Family Details  : ");
        et1=findViewById(id.nameqr);
        et2=findViewById(id.phno1qr);
        et3=findViewById(id.phno2qr);
        et4 = findViewById(R.id.group);
        im1 = findViewById(id.imageButton);
        relativeLayout = findViewById(id.rl);
        qrgen=findViewById(R.id.genqr);
        qr1 = findViewById(R.id.qr);
        dqr=findViewById(id.qrdownload);







        qrgen.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String sText="Name: "+et1.getText().toString().trim()+"\n"+"1st PhoneNumber: "+et2.getText().toString().trim()+"\n"+"2nd PhoneNumber: "+et3.getText().toString().trim()+"\nVictim Bloodgroup : "+et4.getText().toString().trim();
                MultiFormatWriter writer=new MultiFormatWriter();


                try {
                    BitMatrix matrix=writer.encode(sText, BarcodeFormat.QR_CODE,350,350);
                    BarcodeEncoder encoder=new BarcodeEncoder();
                    Bitmap bitmap =encoder.createBitmap(matrix);
                    qr1.setImageBitmap(bitmap);

                    InputMethodManager manager=(InputMethodManager) getSystemService(
                            Context.INPUT_METHOD_SERVICE

                    );
                    manager.hideSoftInputFromWindow(et1.getApplicationWindowToken()
                    ,0);
                } catch (WriterException e) {
                    e.printStackTrace();
                }


            }
        });




       /* dqr.setOnClickListener(new View.OnClickListener() {


            @Override
            public void onClick(View view) {
             bitmapd=(BitmapDrawable) qr1.getDrawable();
             bitmap=bitmapd.getBitmap();
             FileOutputStream file= null;
             File sdcard=Environment.getExternalStorageDirectory();
             File Directory=new File(sdcard.getAbsolutePath()+ "/Download");
             Directory.mkdir();


             String filename=String.format("%d.jpg",System.currentTimeMillis());

             File outfile=new File(Directory,filename);
                Toast.makeText(Login_Activity.this, "Image saved successfully", Toast.LENGTH_LONG).show();
                try {
                   file=new FileOutputStream(outfile);
                   bitmap.compress(Bitmap.CompressFormat.JPEG,100,file);

                   file.flush();
                   file.close();
                    Intent intent=new Intent(Intent.ACTION_MEDIA_SCANNER_SCAN_FILE);
                    intent.setData(Uri.fromFile(outfile));
                    sendBroadcast(intent);

                }
                catch (FileNotFoundException e)
                {
                 e.printStackTrace();
                }
                catch (IOException e)
                {
                    e.printStackTrace();

                }





            }
        });*/
        im1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                SharedPreferences sharedPreferences = getSharedPreferences(SHARED_PREFS,MODE_PRIVATE);
                SharedPreferences.Editor editor = sharedPreferences.edit();

                editor.putString("name","");
                editor.apply();

                Toast.makeText(Login_Activity.this, "Logout Successfull", Toast.LENGTH_SHORT).show();
                Intent in = new Intent(Login_Activity.this,MainActivity.class);
                startActivity(in);
                finish();
            }
        });
        dqr.setOnClickListener(v->{
            i++;
            saveImage();
        });

    }
    private void saveImage() {
        relativeLayout.setDrawingCacheEnabled(true);
        relativeLayout.buildDrawingCache();
        relativeLayout.setDrawingCacheQuality(View.DRAWING_CACHE_QUALITY_HIGH);
        Bitmap bitmap = relativeLayout.getDrawingCache();
        save(bitmap);

    }

    private void save(Bitmap bitmap) {
        String root = Environment.getExternalStorageDirectory().getAbsolutePath();
        File file = new File(root + "/Download");
        String filename = /*"qr" + i + ".jpg"*/ et1.getText().toString()+".jpg";
        File myfile = new File(file, filename);

        if (myfile.exists()) {
            myfile.delete();
        }
        try {
            FileOutputStream fileOutputStream = new FileOutputStream(myfile);
            bitmap.compress(Bitmap.CompressFormat.JPEG, 100, fileOutputStream);
            fileOutputStream.flush();
            fileOutputStream.close();
            //Toast.makeText(this, "Image saved Successfully", Toast.LENGTH_SHORT).show();
            Toast.makeText(this, "path :"+file+"\nImage saved Successfully", Toast.LENGTH_LONG).show();
            relativeLayout.setDrawingCacheEnabled(false);
        } catch (Exception e) {
            Toast.makeText(this, "Error" + e, Toast.LENGTH_SHORT).show();
        }

    }
    @Override
    public void onBackPressed() {
        super.onBackPressed();
        finishAffinity();
    }
}