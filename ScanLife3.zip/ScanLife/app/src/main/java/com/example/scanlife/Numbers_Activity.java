package com.example.scanlife;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class Numbers_Activity extends AppCompatActivity {
    Button o;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_numbers);
        getSupportActionBar().setTitle("Emergency Numbers");
        o=findViewById(R.id.okay);
        o.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent io=new Intent(Numbers_Activity.this,MainActivity.class);
                startActivity(io);
            }
        });
    }
}